let name = "Jai Kant Yadav";

let age = 24

// if i want to store any data other than number i shall put it in a string ie double quotes //


// anything written under "" is considered as string //
console.log(typeof(name));

console.log(typeof(age))
