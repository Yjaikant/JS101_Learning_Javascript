var name = "Jai Kant Yadav";

console.log(name)

// father's Name //

var fname = "Jai Prakash Yadav";

console.log(fname);

// mother"s Name //

var mname = "Seema Kumari";

console.log(mname)