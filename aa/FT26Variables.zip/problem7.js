let a = "Masai School";

console.log(a);

let b = "A Transformation in Education";

console.log(b);
