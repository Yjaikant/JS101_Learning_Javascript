// title - Report card of a student //
let title = "Ｒｅｐｏｔ Ｃａｒｄ";

console.log(title)

let name = "N̲a̲m̲e̲:Jai Kant Yadav"

console.log(name);
let grade = "C̲l̲a̲s̲s̲ :12";
let section = "A";

console.log(grade,section);

let rollno = "R̲o̲l̲l̲ N̲o̲.: 02136";

console.log(rollno);

let school = "S̲c̲h̲o̲o̲l̲:Kendriya Vidyalaya Delhi Cantt.";

console.log(school);

//  Marks Obtained //
let M = "Ｍａｒｋｓ";

console.log(M);

const sub1 = "𝖯𝗁𝗒𝗌𝗂𝖼𝗌:87";
console.log(sub1);

const sub2 = "𝖢𝗁𝖾𝗆𝗂𝗌𝗍𝗋𝗒:92";
console.log(sub2);

const sub3 = "𝖬𝖺𝗍𝗁𝗌:96";
console.log(sub3);

var x = 275;
var y = "Tᴏᴛᴀʟ Mᴀʀᴋs:";

console.log(y,x);

// assignment completed //








