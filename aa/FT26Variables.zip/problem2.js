let Y = 10

let y = 23

console.log(Y)