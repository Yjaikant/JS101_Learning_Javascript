let name = "Jai Kant Yadav";

console.log(name);

let age = 26;

console.log(typeof(age));