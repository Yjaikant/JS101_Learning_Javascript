let x = 10;

console.log(x)

let a = 20;

a = 20;

console.log(a)

          