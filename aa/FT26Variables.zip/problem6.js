let a = 23;

console.log(a);

const b = 67;

console.log(typeof(b));