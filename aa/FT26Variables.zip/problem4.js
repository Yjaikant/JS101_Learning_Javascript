var a = 11

console.log(a)

const b = 78

console.log(b)
        